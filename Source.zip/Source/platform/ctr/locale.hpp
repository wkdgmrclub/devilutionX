#pragma once

#include <string>

namespace devilution {
namespace n3ds {

std::string GetLocale();

} // namespace n3ds
} // namespace devilution
