#pragma once

void ctr_lcd_backlight_on();
void ctr_lcd_backlight_off();

bool ctr_check_dsp();

void ctr_sys_init();
