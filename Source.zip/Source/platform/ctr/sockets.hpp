#pragma once

namespace devilution {

void n3ds_socInit();
void n3ds_socExit();

} // namespace devilution
