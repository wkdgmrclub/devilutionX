#pragma once

#include_next <sys/ioctl.h>

#define FIONREAD -999
