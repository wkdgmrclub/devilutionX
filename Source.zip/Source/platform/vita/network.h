#pragma once

void vita_enable_network();
