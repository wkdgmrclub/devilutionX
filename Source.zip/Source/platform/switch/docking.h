#pragma once

namespace devilution {

void HandleDocking();

} // namespace devilution
