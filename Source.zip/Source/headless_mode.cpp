#include "headless_mode.hpp"

namespace devilution {

bool HeadlessMode;

} // namespace devilution
