#pragma once

#include <sol/sol.hpp>

namespace devilution {

sol::table LuaLogModule(sol::state_view &lua);

} // namespace devilution
