#pragma once

#include <sol/sol.hpp>

namespace devilution {

sol::table LuaItemModule(sol::state_view &lua);

} // namespace devilution
