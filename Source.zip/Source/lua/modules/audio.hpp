#pragma once

#include <sol/sol.hpp>

namespace devilution {

sol::table LuaAudioModule(sol::state_view &lua);

} // namespace devilution
