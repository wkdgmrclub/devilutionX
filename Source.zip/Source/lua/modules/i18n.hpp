#pragma once

#include <sol/sol.hpp>

namespace devilution {

sol::table LuaI18nModule(sol::state_view &lua);

} // namespace devilution
