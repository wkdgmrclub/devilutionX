#pragma once

#include <sol/sol.hpp>

namespace devilution {

sol::table LuaRenderModule(sol::state_view &lua);

} // namespace devilution
