#pragma once

namespace devilution {

void UiSelStartUpGameOption();

} // namespace devilution
